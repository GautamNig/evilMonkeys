#include "game.h"
int main()
{
	Game game;
	game.run();
	return 0;
}